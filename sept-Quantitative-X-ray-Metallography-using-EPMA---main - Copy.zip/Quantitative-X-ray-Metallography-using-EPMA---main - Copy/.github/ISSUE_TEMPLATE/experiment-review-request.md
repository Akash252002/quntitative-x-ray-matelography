---
name: Experiment  Review Request
about: 'Get your experiment reviewed '
title: 'Request for Review of Experiment - '
labels: request for review
assignees: ''

---

## *Experiment  Review Request*
Use this to get experiment reviewed.

1. *Exp Name*:<!--Fill the name of the experiment-->
2. *Domain*:<!-- Fill the domain/discipline that the experiment belongs to-->
3. *Lab Name*:<!-- Fill the name of the lab that the experiment belongs to-->
4. *Testing URL*:<!-- https://virtual-labs.github.io/${{ github.repository }} --!>
