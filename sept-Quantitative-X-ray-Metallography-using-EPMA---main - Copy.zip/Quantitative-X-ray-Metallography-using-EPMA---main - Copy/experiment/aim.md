### Aim of the experiment
