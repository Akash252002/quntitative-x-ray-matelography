## Introduction


<b>Discipline | <b>Material Science and Engineering
:--|:--|
<b> Lab | <b> Charaterization of Materials
<b> Experiment|     <b> Quantitative-X-ray-Metallography-using-EPMA
### About the Experiment 

Fill a brief description of this experiment here

<b>Name of Developer | <b> Prof. Kantesh Balani 
:--|:--|
<b> Institute | Indian Institude of Technology, Kanpur <b>  
<b> Email id|  kbalani@iitk.ac.in   <b>  
<b> Department |  Material Science and Engineering 

### Contributors List

SrNo | Name | Faculty or Student | Department| Institute | Email id
:--|:--|:--|:--|:--|:--|
1 |Akash Kumar | Student | Computer Science and Engineering | Bundelkhand University, Jhansi | akasr1603@gmail.com
2 | . | . | . | . | .
